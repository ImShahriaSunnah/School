$(document).ready(function () {
   // alert('hello');
    getNotification(29);
});

function getNotification(user_id){
    $.ajax({
        method :"GET",
        url : 'api/notification/' + user_id,
        success: (result) => {
            // console.log(`result`,result);
            $("#post-comments").html(result)

        }
    })
}
